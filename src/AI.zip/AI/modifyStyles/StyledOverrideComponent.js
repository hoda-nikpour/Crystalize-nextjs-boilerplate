import React from 'react';
import styled, { createGlobalStyle } from 'styled-components';

// Dynamic global style override using props
const GlobalStyleOverride = createGlobalStyle`
  :root {
    --color-main-background: ${({ mainBackground }) =>
      mainBackground || '#fff'};
    --color-text-main: ${({ textMain }) => textMain || '#080708'};
    --color-text-sub: ${({ textSub }) => textSub || '#4c505b'};
    --color-box-background: ${({ boxBackground }) =>
      boxBackground || '#efefef'};
  }
`;

const Wrapper = styled.div`
  background-color: var(--color-main-background);
  color: var(--color-text-main);
  min-height: 100vh;
  padding: 20px;
`;

const Title = styled.h1`
  color: var(--color-text-main);
`;

const Subtitle = styled.h2`
  color: var(--color-text-sub);
`;

const Box = styled.div`
  background-color: var(--color-box-background);
  padding: 20px;
  border-radius: 8px;
  margin-top: 20px;
`;

const StyledOverrideComponent = ({
  mainBackground,
  textMain,
  textSub,
  boxBackground
}) => {
  return (
    <>
      <GlobalStyleOverride
        mainBackground={mainBackground}
        textMain={textMain}
        textSub={textSub}
        boxBackground={boxBackground}
      />
      <Wrapper>
        <Title>Welcome to the Updated Theme</Title>
        <Subtitle>This subtitle is styled with the new subtext color</Subtitle>
        <Box>
          This box has a new background color and respects the updated styles.
        </Box>
      </Wrapper>
    </>
  );
};

export default StyledOverrideComponent;
