import React, { useEffect, useState, useCallback } from 'react';
import * as tf from '@tensorflow/tfjs';
import StyledOverrideComponent from 'AI/modifyStyles/StyledOverrideComponent';

export default function AnalyzedByTraditionalAI({ image1, image2 }) {
  const [colors, setColors] = useState(null); // Initially null to indicate loading state

  const predictColors = useCallback(async (image1, image2) => {
    try {
      const img1 = await loadImage(image1);
      const img2 = await loadImage(image2);

      const imageData1 = getImageData(img1);
      const imageData2 = getImageData(img2);

      const combinedPixels = extractPixels(imageData1).concat(
        extractPixels(imageData2)
      );

      const colors = await kMeansClustering(combinedPixels, 4);
      const uiColors = mapColorsToUI(colors);
      setColors(uiColors); // Update state with predicted colors
    } catch (error) {
      console.error('Error in predicting colors:', error);
    }
  }, []);

  useEffect(() => {
    if (image1 && image2) {
      predictColors(image1, image2);
    }
    // Cleanup function to dispose of any lingering tensors
    return () => {
      tf.disposeVariables();
    };
  }, [image1, image2, predictColors]);

  const loadImage = (src) => {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = src;
      img.onload = () => resolve(img);
    });
  };

  const getImageData = (img) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);
    return ctx.getImageData(0, 0, img.width, img.height);
  };

  const extractPixels = (imageData) => {
    const pixels = [];
    for (let i = 0; i < imageData.data.length; i += 4) {
      pixels.push([
        imageData.data[i],
        imageData.data[i + 1],
        imageData.data[i + 2]
      ]);
    }
    return pixels;
  };

  const kMeansClustering = async (pixels, k) => {
    return tf.tidy(() => {
      const input = tf.tensor2d(pixels, [pixels.length, 3]);
      let centroids = tf.slice(input, [0, 0], [k, -1]);

      for (let i = 0; i < 10; i++) {
        const expandedCentroids = centroids
          .expandDims(0)
          .tile([pixels.length, 1, 1]);
        const expandedPixels = input.expandDims(1);
        const distances = tf.sum(
          tf.square(expandedPixels.sub(expandedCentroids)),
          -1
        );
        const assignments = tf.argMin(distances, 1);

        const means = [];
        for (let j = 0; j < k; j++) {
          const mask = tf.equal(assignments, j);
          const maskedPixels = tf.mul(input, mask.expandDims(1));

          const sum = maskedPixels.sum(0);
          const count = mask.sum();
          const mean = tf.div(sum, tf.maximum(count, 1));
          means.push(mean);
        }

        if (means.length > 0) {
          centroids = tf.stack(means, 0);
        }
      }

      const finalCentroids = centroids.arraySync();
      return finalCentroids;
    });
  };

  const mapColorsToUI = (colors) => {
    return {
      mainBackgroundColor: ensureColorRange(rgbToHex(colors[0]), 'orange'),
      textMainColor: ensureColorRange(rgbToHex(colors[1]), 'dark-cream'),
      textSubColor: ensureColorRange(rgbToHex(colors[2]), 'light-brown'),
      boxBackgroundColor: ensureColorRange(rgbToHex(colors[3]), 'light-brown')
    };
  };

  const ensureColorRange = (hexColor, targetColor) => {
    const targetHex = colorMap[targetColor];
    if (!targetHex) return hexColor;

    const [r, g, b] = hexToRgb(hexColor);
    const [tr, tg, tb] = hexToRgb(targetHex);

    // Adjust the extracted color towards the target tone
    const adjustedColor = [
      Math.round(r * 0.7 + tr * 0.3),
      Math.round(g * 0.7 + tg * 0.3),
      Math.round(b * 0.7 + tb * 0.3)
    ];

    return rgbToHex(adjustedColor);
  };

  const hexToRgb = (hex) => {
    const bigint = parseInt(hex.slice(1), 16);
    return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
  };

  const rgbToHex = ([r, g, b]) => {
    return `#${((1 << 24) + (r << 16) + (g << 8) + b)
      .toString(16)
      .slice(1)
      .toUpperCase()}`;
  };

  const colorMap = {
    orange: '#FEB265', // Orangish tone
    'dark-cream': '#F4D03F', // Dark creamy tone
    'light-brown': '#D7BDE2' // Light brownish tone
  };

  if (!colors) {
    return <div>Loading...</div>; // Render a loading state while colors are being predicted
  }

  return (
    <>
      {console.log(
        colors.mainBackgroundColor,
        colors.textMainColor,
        colors.textSubColor,
        colors.boxBackgroundColor
      )}

      <StyledOverrideComponent
        mainBackground={colors.mainBackgroundColor}
        textMain={colors.textMainColor}
        textSub={colors.textSubColor}
        boxBackground={colors.boxBackgroundColor}
      />
    </>
  );
}
/*
088487b14919b06ca7e2
0e55ea131adb37b6a94177ec7229cb29cf7bdc0b
CRYSTALLIZE_TENANT_ID=66ba18246a7ef7ce34dc9702
CRYSTALLIZE_TENANT_IDENTIFIER=hoda
CRYSTALLIZE_ACCESS_TOKEN_ID=088487b14919b06ca7e2
CRYSTALLIZE_ACCESS_TOKEN_SECRET=0e55ea131adb37b6a94177ec7229cb29cf7bdc0b
*/
